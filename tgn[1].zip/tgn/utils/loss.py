import torch
import torch.nn as nn

class CustomLoss(nn.Module):
    def __init__(self, weight_fp, weight_fn):
        super(CustomLoss, self).__init__()
        self.weight_fp = weight_fp
        self.weight_fn = weight_fn

    def forward(self, y_pred, y_true):
        # Compute the binary cross-entropy loss
        
        bce_loss = torch.nn.functional.binary_cross_entropy(y_pred, y_true, )
        
        # Compute the false positives and false negatives
        false_positives = torch.sum((y_pred > 0.5) & (y_true == 0))
        false_negatives = torch.sum((y_pred <= 0.5) & (y_true == 1))
        
        # Combine the costs of false positives and false negatives
        loss = bce_loss + (self.weight_fp * false_positives + self.weight_fn * false_negatives)
        
        return loss


class WeightedBCELoss(nn.Module):
    def __init__(self, weight_fp, weight_fn):
        super(WeightedBCELoss, self).__init__()
        self.weight_fp = weight_fp
        self.weight_fn = weight_fn

    def forward(self, y_pred, y_true):
        # Compute weights for positive and negative examples
        weights = y_true * self.weight_fn + (1 - y_true) * self.weight_fp
        
        # Compute the weighted binary cross-entropy loss
        bce_loss = torch.nn.functional.binary_cross_entropy(y_pred, y_true, weight=weights)
        
        return bce_loss


 