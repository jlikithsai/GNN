import math
import logging
import time
import sys
import random
import argparse
import pickle
from pathlib import Path

import torch.nn as nn
import torch
import torch.nn.functional as F
import numpy as np
import pandas as pd

from utils.loss import CustomLoss,WeightedBCELoss
from model.tgn import TGN
from utils.utils import EarlyStopMonitor, get_neighbor_finder, MLP ,HeteroMLPPredictor,ComplexMLP,CNNDecoder
from utils.data_processing import compute_time_statistics, get_data_node_classification
from evaluation.evaluation import eval_node_classification

random.seed(0)
np.random.seed(0)
torch.manual_seed(0)

### Argument and global variables
parser = argparse.ArgumentParser('TGN self-supervised training')
parser.add_argument('-d', '--data', type=str, help='Dataset name (eg. wikipedia or reddit)',
                    default='wikipedia')
parser.add_argument('--bs', type=int, default=200, help='Batch_size')
parser.add_argument('--prefix', type=str, default='', help='Prefix to name the checkpoints')
parser.add_argument('--n_degree', type=int, default=10, help='Number of neighbors to sample')
parser.add_argument('--n_head', type=int, default=2, help='Number of heads used in attention layer')
parser.add_argument('--n_epoch', type=int, default=30, help='Number of epochs')
parser.add_argument('--n_layer', type=int, default=1, help='Number of network layers')
parser.add_argument('--lr', type=float, default=1e-4, help='Learning rate')
parser.add_argument('--patience', type=int, default=5, help='Patience for early stopping')
parser.add_argument('--n_runs', type=int, default=10, help='Number of runs')
parser.add_argument('--drop_out', type=float, default=0.1, help='Dropout probability')
parser.add_argument('--gpu', type=int, default=0, help='Idx for the gpu to use')
parser.add_argument('--node_dim', type=int, default=100, help='Dimensions of the node embedding')
parser.add_argument('--time_dim', type=int, default=100, help='Dimensions of the time embedding')
parser.add_argument('--backprop_every', type=int, default=1, help='Every how many batches to '
                                                                  'backprop')
parser.add_argument('--use_memory', action='store_true',default=False,
                    help='Whether to augment the model with a node memory')
parser.add_argument('--embedding_module', type=str, default="graph_attention", choices=[
  "graph_attention", "graph_sum", "identity", "time"], help='Type of embedding module')
parser.add_argument('--message_function', type=str, default="identity", choices=[
  "mlp", "identity"], help='Type of message function')
parser.add_argument('--aggregator', type=str, default="last", help='Type of message '
                                                                        'aggregator')
parser.add_argument('--memory_update_at_end', action='store_true',
                    help='Whether to update memory at the end or at the start of the batch')
parser.add_argument('--message_dim', type=int, default=100, help='Dimensions of the messages')
parser.add_argument('--memory_dim', type=int, default=172, help='Dimensions of the memory for '
                                                                'each user')
parser.add_argument('--different_new_nodes', action='store_true',
                    help='Whether to use disjoint set of new nodes for train and val')
parser.add_argument('--uniform', action='store_true',
                    help='take uniform sampling from temporal neighbors')
parser.add_argument('--randomize_features', action='store_true',
                    help='Whether to randomize node features')
parser.add_argument('--use_destination_embedding_in_message', action='store_true',
                    help='Whether to use the embedding of the destination node as part of the message')
parser.add_argument('--use_source_embedding_in_message', action='store_true',
                    help='Whether to use the embedding of the source node as part of the message')
parser.add_argument('--n_neg', type=int, default=1)
parser.add_argument('--use_validation', action='store_true',default=True,
                    help='Whether to use a validation set')
parser.add_argument('--new_node', action='store_true', help='model new node')

try:
  args = parser.parse_args()
except:
  parser.print_help()
  sys.exit(0)

BATCH_SIZE = args.bs
NUM_NEIGHBORS = 5
NUM_NEG = 1
NUM_EPOCH = args.n_epoch
NUM_HEADS = args.n_head
DROP_OUT = args.drop_out
GPU = args.gpu
UNIFORM = args.uniform
NEW_NODE = args.new_node
SEQ_LEN = NUM_NEIGHBORS
DATA = args.data
NUM_LAYER = args.n_layer
LEARNING_RATE = args.lr
NODE_LAYER = 1
NODE_DIM = args.node_dim
TIME_DIM = args.time_dim
USE_MEMORY = False
MESSAGE_DIM = args.message_dim
MEMORY_DIM = args.memory_dim

Path("./saved_models/").mkdir(parents=True, exist_ok=True)
Path("./saved_checkpoints/").mkdir(parents=True, exist_ok=True)
MODEL_SAVE_PATH = f'./saved_models/{args.prefix}-{args.data}' + '\
  node-classification.pth'
get_checkpoint_path = lambda \
    epoch: f'./saved_checkpoints/{args.prefix}-{args.data}-{epoch}' + '\
  node-classification.pth'


#todo - check logger need

full_data, node_features, edge_features, train_data, val_data, test_data = \
  get_data_node_classification(DATA, use_validation=args.use_validation)

max_idx = max(full_data.unique_nodes)

ngh_finder = get_neighbor_finder(full_data, uniform=UNIFORM, max_node_idx= max_idx)

device_string = 'cuda:{}'.format(GPU) if torch.cuda.is_available() else 'cpu'
device = torch.device(device_string)

# Compute time statistics
mean_time_shift_src, std_time_shift_src, mean_time_shift_dst, std_time_shift_dst = \
   compute_time_statistics(full_data.sources, full_data.destinations, full_data.timestamps)

import pandas as pd
import numpy as np
import torch

# Function to process a batch and compute embeddings
def process_batch(tgn, sources_batch, destinations_batch, timestamps_batch, edge_idxs_batch, labels_batch, num_neighbors):
    with torch.no_grad():
        source_embedding, destination_embedding, _ = tgn.compute_temporal_embeddings(
            sources_batch, destinations_batch, destinations_batch,
            timestamps_batch, edge_idxs_batch, num_neighbors)
        
        embeddings = torch.cat([destination_embedding, source_embedding], dim=1).numpy()
        df = pd.DataFrame(embeddings)
        df.insert(0, 'src', sources_batch)
        df.insert(1, 'dst', destinations_batch)
        df.insert(2, 'ts', timestamps_batch)
        df.insert(3, 'idx', edge_idxs_batch)
        df.insert(4, 'label', labels_batch)
        
    return df

# Initialize model (as in the provided code)
import pandas as pd
import numpy as np
import torch

# Function to process a batch and compute embeddings
import pandas as pd
import numpy as np
import torch
from tqdm import tqdm

# Function to process a batch and compute embeddings
def process_batch(tgn, sources_batch, destinations_batch, timestamps_batch, edge_idxs_batch, labels_batch, num_neighbors):
    with torch.no_grad():
        source_embedding, destination_embedding, _ = tgn.compute_temporal_embeddings(
            sources_batch, destinations_batch, destinations_batch,
            timestamps_batch, edge_idxs_batch, num_neighbors)
        
        embeddings = torch.cat([destination_embedding, source_embedding], dim=1).numpy()
        df = pd.DataFrame(embeddings)
        df.insert(0, 'src', sources_batch)
        df.insert(1, 'dst', destinations_batch)
        df.insert(2, 'ts', timestamps_batch)
        df.insert(3, 'idx', edge_idxs_batch)
        df.insert(4, 'label', labels_batch)
        
    return df

# Initialize model (as in the provided code)
tgn = TGN(neighbor_finder=ngh_finder, node_features=node_features,
          edge_features=edge_features, device=device,
          n_layers=NUM_LAYER, n_heads=NUM_HEADS, dropout=DROP_OUT,
          use_memory=USE_MEMORY, message_dimension=MESSAGE_DIM,
          memory_dimension=MEMORY_DIM, memory_update_at_start=not args.memory_update_at_end,
          embedding_module_type=args.embedding_module, message_function=args.message_function,
          aggregator_type=args.aggregator, n_neighbors=NUM_NEIGHBORS,
          mean_time_shift_src=mean_time_shift_src, std_time_shift_src=std_time_shift_src,
          mean_time_shift_dst=mean_time_shift_dst, std_time_shift_dst=std_time_shift_dst,
          use_destination_embedding_in_message=args.use_destination_embedding_in_message,
          use_source_embedding_in_message=args.use_source_embedding_in_message)

tgn = tgn.to(device)
model_path = './saved_models/-wikipedia.pth'
tgn.load_state_dict(torch.load(model_path), strict=False)
tgn = tgn.eval()

# Data loading (assuming full_data is loaded)
sources = full_data.sources
destinations = full_data.destinations
timestamps = full_data.timestamps
edge_idxs = full_data.edge_idxs
labels = full_data.labels

batch_size = 1000
num_batches = len(sources) // batch_size + int(len(sources) % batch_size != 0)

# Process in batches and save to CSV
all_dfs = []

print("Starting batch processing...")

for i in tqdm(range(num_batches), desc="Processing Batches"):
    print(f"Processing batch {i + 1}/{num_batches}")
    
    start_idx = i * batch_size
    end_idx = min((i + 1) * batch_size, len(sources))
    
    sources_batch = sources[start_idx:end_idx]
    destinations_batch = destinations[start_idx:end_idx]
    timestamps_batch = timestamps[start_idx:end_idx]
    edge_idxs_batch = edge_idxs[start_idx:end_idx]
    labels_batch = labels[start_idx:end_idx]
    
    df_batch = process_batch(tgn, sources_batch, destinations_batch, timestamps_batch, edge_idxs_batch, labels_batch, NUM_NEIGHBORS)
    all_dfs.append(df_batch)

print("Batch processing completed. Concatenating results...")

# Concatenate all dataframes and save to a single CSV file
final_df = pd.concat(all_dfs, ignore_index=True)
final_df.to_csv('embeddings.csv', index=False)

print("Embeddings saved to embeddings.csv")
